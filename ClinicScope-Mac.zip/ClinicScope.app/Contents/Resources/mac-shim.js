/* Clinic Scope – macOS bridge (WKWebView).
   - marks the page as the Mac app (device-memory import wizard)
   - adds the USB id "(vvvv:pppp)" to camera names so the exam screen picks scope / otoscope mode
   - report window -> native print panel (Save as PDF), external links -> default browser */
(function () {
  window.__macApp = true;
  var H = window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.clinic;
  var post = function (m) { try { H && H.postMessage(m); } catch (e) {} };
  window.__macCams = window.__macCams || [];

  var tag = function (label) {
    if (!label) return label;
    var c = (window.__macCams || []).filter(function (x) { return x.name === label && x.id; })[0];
    return c && label.indexOf(c.id) < 0 ? label + ' (' + c.id + ')' : label;
  };

  var md = navigator.mediaDevices;
  if (md && md.enumerateDevices) {
    var _enum = md.enumerateDevices.bind(md);
    md.enumerateDevices = async function () {
      var l = Array.from(await _enum());
      return l.map(function (d) {
        if (d.kind !== 'videoinput') return d;
        var lab = tag(d.label);
        if (lab === d.label) return d;
        return { deviceId: d.deviceId, groupId: d.groupId, kind: d.kind, label: lab, toJSON: function () { return this; } };
      });
    };
    var _gum = md.getUserMedia.bind(md);
    md.getUserMedia = async function (c) {
      var s = await _gum(c);
      s.getVideoTracks().forEach(function (t) {
        var orig = t.label;
        try { Object.defineProperty(t, 'label', { get: function () { return tag(orig); } }); } catch (e) {}
      });
      return s;
    };
  }

  /* report: the exam screen writes the report into window.open('') and calls print() */
  window.open = function (url) {
    if (!url || url === 'about:blank') {
      var buf = '';
      var doc = {
        write: function () { buf += Array.prototype.join.call(arguments, ''); },
        writeln: function () { buf += Array.prototype.join.call(arguments, '') + '\n'; },
        open: function () { buf = ''; },
        close: function () {
          var m = buf.match(/<title>([\s\S]*?)<\/title>/i);
          post({ type: 'print', html: buf, title: m ? m[1] : 'تقرير الفحص' });
        }
      };
      return { document: doc, print: function () {}, focus: function () {}, close: function () {} };
    }
    post({ type: 'open', url: new URL(url, location.href).href });
    return null;
  };

  window.addEventListener('error', function (e) { post({ type: 'log', msg: 'js error: ' + (e && e.message) }); });
  window.addEventListener('unhandledrejection', function (e) { post({ type: 'log', msg: 'js promise: ' + (e && e.reason && (e.reason.message || e.reason)) }); });
})();
